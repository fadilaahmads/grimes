<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class wel2controller extends Controller
{
    public function index(){
        return view('welcome2');
    }
}
