<!doctype html>
<html lang="en">
  <head>
    <title>Tunggu konfirmasi Admin</title>
  </head>
<body>
    <h5>homestay anda telah dikirim dan sedang menunggu verifikasi dari admin</h5>
    <a href=/welcome>Kembali ke menu utama</a>
</body>
</html>
<?php /**PATH D:\..Penting\htdocs\tubes99\resources\views/tunnguVerif.blade.php ENDPATH**/ ?>