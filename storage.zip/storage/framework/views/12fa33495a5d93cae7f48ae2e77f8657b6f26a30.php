<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <!--<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    -->
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <title><?php echo $__env->yieldContent('title); ?></title>
  </head>
<body>

<style>
    #tdfirst{
        
        padding: 0px 0px;
    }
    .centered {
        position: absolute;
        top: 40%;
        left: 5%;
        color: white;
    }
    #jelajah{
      width: 300px;
      background-color: #286aad;
      color: white;
    }
    #try1{
        color: white;
        position: absolute;
        top: 48%;
        
    }
    #try2{
        position: absolute;
        top: 50%;
        left: 26%;
    }
    .navbar{
        height: 70px;
    }
    .trkota{
        top: 20%;
    }
    #gh{
      color: #1f274e;
    }
</style>
<nav class="navbar fixed-top navbar-expand-lg navbar-light" style="background-color: #ffffff;">
  <a class="navbar-brand font-weight-bold ml-4" href="#"><big id="gh">Griya Homestay</big></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse">
    <ul class="navbar-nav ml-auto mr-5">
      <li class="nav-item active">
        <a class="nav-link" href="/formlogin">Login</a>
      </li>
      <li class="nav-item active ml-3 mr-3">
        <a class="nav-link" href="/formsignup">Sign Up</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="#">About</a>
      </li>
    </ul>
  </div>
  </nav> 

 <?php echo $__env->yieldContent('container'); ?>

</body>
</html> ?><?php /**PATH C:\xampp\htdocs\tubes2\resources\views/main.blade.php ENDPATH**/ ?>