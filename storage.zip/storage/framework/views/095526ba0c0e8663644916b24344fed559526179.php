<?php $__env->startSection('content'); ?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <!--<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    -->
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <title>Griya Homestay</title>
  </head>
<body>

<style>
    tr, th {
        padding: 10px 10px;
    }
</style>

</div>
    <div class="container">
        <div class="row">
          <div class="col-10">
                <h1 class="mt-3 font-weight-bold">Data Homestay</h1>
<table class="table">
  <thead class="thead-dark">
    <tr>
      
      <th scope="col">Nama Homestay</th>
      <th scope="col">Alamat</th>
      <th scope="col">Kota</th>
      <th scope="col">Pemilik</th>
      <th scope="col">Jumlah Kamar</th>
      <th scope="col">Harga Tertinggi</th>
      <th scope="col">Harga Terendah</th>
      <th scope="col">Nomor Telepon</th>
      <th scope="col">Foto</th>
      <th scope="col">Aksi</th>
      <th scope="col">Foto Tampil</th>
    </tr>
    <?php $__currentLoopData = $homestay; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	  <tr>
        <td><?php echo e($p->homestay_nama); ?></td>
        <td><?php echo e($p->homestay_alamat); ?></td>
        <td><?php echo e($p->homestay_kota); ?></td>
        <td><?php echo e($p->homestay_pemilik); ?></td>
        <td><?php echo e($p->homestay_jumlah_kamar); ?></td>
        <td><?php echo e($p->homestay_harga_tertinggi); ?></td>
        <td><?php echo e($p->homestay_harga_terendah); ?></td>
        <td><?php echo e($p->homestay_telepon); ?></td>
        <td><?php echo e($p->homestay_foto); ?></td>
        <td><img width="150px" src="<?php echo e(url('/uploads/'.$p->homestay_foto)); ?>"></td>
        <td>
          <a href="/homestay/edit/<?php echo e($p->homestay_id); ?>">Edit</a>
          
          <a href="/homestay/hapus/<?php echo e($p->homestay_id); ?>">Hapus</a>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
      
 
  </thead>
</table>
      Halaman : <?php echo e($homestay->currentPage()); ?> <br/>
      Jumlah Data : <?php echo e($homestay->total()); ?> <br/>
      Data Per Halaman : <?php echo e($homestay->perPage()); ?> <br/>
    
    
      <?php echo e($homestay->links()); ?>

</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\..Penting\htdocs\tubes99\resources\views/tabel1.blade.php ENDPATH**/ ?>