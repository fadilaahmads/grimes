<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <!--<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    -->
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <title>Griya Homestay</title>
  </head>
<body>
<style>
    table{
        background-image: url("images/gambar1.jpg");
        width: 1100px;
        height: 600px;
    }
</style>
    <div class="container-fluid">
    <table border="1">
        <tr>
            <td></td>
        </tr>
    </table>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\tubes2\resources\views/tabel1.blade.php ENDPATH**/ ?>